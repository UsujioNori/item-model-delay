package com.usujiotarako.client;

import net.minecraft.resources.Identifier;

import java.util.HashMap;
import java.util.Map;

public final class ModelDelayConfig {

    private static final Map<
            Identifier,
            ItemConfig
            > CONFIGS = new HashMap<>();


    private ModelDelayConfig() {
    }


    /*
     * ================================================================
     * DELAY MODE
     * ================================================================
     */
    public enum Mode {
        HOLD,
        RELEASE,
        BOTH
    }


    /*
     * ================================================================
     * ITEM BEHAVIOR
     * ================================================================
     *
     * Applies to the entire .mdprop file.
     */
    public enum Behavior {
        NORMAL,
        EVOLVING
    }


    /*
     * ================================================================
     * PROPERTY BEHAVIOR
     * ================================================================
     *
     * NORMAL:
     *
     *     Existing Model Delay behavior.
     *
     *
     * HELD:
     *
     *     While actively held:
     *
     *         use the property's actual vanilla value.
     *
     *     While not held:
     *
     *         feed FALSE into ModelDelayState.
     *
     *
     *     HOLD / RELEASE / BOTH still determine how that change is
     *     visually delayed.
     */
    public enum PropertyBehavior {
        NORMAL,
        HELD
    }


    public record DelayConfig(
            int delay,
            Mode mode,
            PropertyBehavior behavior
    ) {

        /*
         * Compatibility constructor.
         */
        public DelayConfig(
                int delay,
                Mode mode
        ) {

            this(
                    delay,
                    mode,
                    PropertyBehavior.NORMAL
            );
        }
    }


    public record ItemConfig(
            Behavior behavior,
            Map<String, DelayConfig> properties
    ) {
    }


    /*
     * ================================================================
     * CLEAR
     * ================================================================
     */
    public static void clear() {

        CONFIGS.clear();
    }


    /*
     * ================================================================
     * REGISTER ITEM
     * ================================================================
     */
    public static void registerItem(
            Identifier itemId,
            Behavior behavior,
            Map<String, DelayConfig> properties
    ) {

        CONFIGS.put(
                itemId,
                new ItemConfig(
                        behavior,
                        new HashMap<>(properties)
                )
        );
    }


    /*
     * Compatibility overload.
     */
    public static void registerItem(
            Identifier itemId,
            Map<String, DelayConfig> properties
    ) {

        registerItem(
                itemId,
                Behavior.NORMAL,
                properties
        );
    }


    /*
     * ================================================================
     * PROPERTY CONFIG
     * ================================================================
     */
    public static DelayConfig get(
            Identifier itemId,
            String propertyName
    ) {

        ItemConfig itemConfig =
                CONFIGS.get(
                        itemId
                );


        if (itemConfig == null) {
            return null;
        }


        return itemConfig.properties().get(
                propertyName
        );
    }


    /*
     * ================================================================
     * ITEM BEHAVIOR
     * ================================================================
     */
    public static Behavior getBehavior(
            Identifier itemId
    ) {

        ItemConfig itemConfig =
                CONFIGS.get(
                        itemId
                );


        if (itemConfig == null) {

            return Behavior.NORMAL;
        }


        return itemConfig.behavior();
    }


    public static boolean isEvolving(
            Identifier itemId
    ) {

        return getBehavior(itemId)
                == Behavior.EVOLVING;
    }
}