package com.usujiotarako.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class ModelDelayHelperClient
		implements ClientModInitializer {

	@Override
	public void onInitializeClient() {

		ModelDelayResourceLoader.initialize();


		ClientTickEvents.END_CLIENT_TICK.register(
				client -> {

					/*
					 * Existing boolean/conditional state.
					 */
					ModelDelayState.tick();


					/*
					 * New numeric/range_dispatch state.
					 */
					ModelDelayRangeState.tick();
				}
		);
	}
}