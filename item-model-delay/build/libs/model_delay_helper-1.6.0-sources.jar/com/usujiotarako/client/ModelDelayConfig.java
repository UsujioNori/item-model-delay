package com.usujiotarako.client;

import net.minecraft.resources.Identifier;

import java.util.HashMap;
import java.util.Map;

public final class ModelDelayConfig {

    private static final Map<
            Identifier,
            ItemConfig
            > CONFIGS = new HashMap<>();


    private ModelDelayConfig() {
    }


    /*
     * ================================================================
     * CONDITIONAL DELAY MODE
     * ================================================================
     */
    public enum Mode {
        HOLD,
        RELEASE,
        BOTH
    }


    /*
     * ================================================================
     * ITEM BEHAVIOR
     * ================================================================
     */
    public enum Behavior {
        NORMAL,
        EVOLVING
    }


    /*
     * ================================================================
     * CONDITIONAL PROPERTY BEHAVIOR
     * ================================================================
     */
    public enum PropertyBehavior {
        NORMAL,
        HELD
    }


    /*
     * ================================================================
     * RANGE PROPERTY BEHAVIOR
     * ================================================================
     *
     * THRESHOLD:
     *
     *     Default behavior.
     *
     *     Delay only when the numeric value moves into a different
     *     range_dispatch threshold/model region.
     *
     *     Raw value changes inside the same region do not create or
     *     restart a timer.
     *
     *
     * VALUE:
     *
     *     Delay every actual numeric value change.
     *
     *     This remains available as an explicit advanced option.
     */
    public enum RangeBehavior {
        THRESHOLD,
        VALUE
    }


    /*
     * ================================================================
     * CONDITIONAL CONFIG
     * ================================================================
     */
    public record DelayConfig(
            int delay,
            Mode mode,
            PropertyBehavior behavior
    ) {

        /*
         * Compatibility constructor.
         */
        public DelayConfig(
                int delay,
                Mode mode
        ) {

            this(
                    delay,
                    mode,
                    PropertyBehavior.NORMAL
            );
        }
    }


    /*
     * ================================================================
     * RANGE CONFIG
     * ================================================================
     */
    public record RangeDelayConfig(
            int delay,
            RangeBehavior behavior
    ) {

        /*
         * Default numeric behavior is threshold-aware.
         */
        public RangeDelayConfig(
                int delay
        ) {

            this(
                    delay,
                    RangeBehavior.THRESHOLD
            );
        }
    }


    /*
     * ================================================================
     * ITEM CONFIG
     * ================================================================
     */
    public record ItemConfig(
            Behavior behavior,
            Map<String, DelayConfig> properties,
            Map<String, RangeDelayConfig> rangeProperties
    ) {
    }


    /*
     * ================================================================
     * CLEAR
     * ================================================================
     */
    public static void clear() {

        CONFIGS.clear();
    }


    /*
     * ================================================================
     * REGISTER ITEM
     * ================================================================
     */
    public static void registerItem(
            Identifier itemId,
            Behavior behavior,
            Map<String, DelayConfig> properties,
            Map<String, RangeDelayConfig> rangeProperties
    ) {

        CONFIGS.put(
                itemId,
                new ItemConfig(
                        behavior,
                        new HashMap<>(properties),
                        new HashMap<>(rangeProperties)
                )
        );
    }


    /*
     * Compatibility overload.
     */
    public static void registerItem(
            Identifier itemId,
            Behavior behavior,
            Map<String, DelayConfig> properties
    ) {

        registerItem(
                itemId,
                behavior,
                properties,
                Map.of()
        );
    }


    /*
     * Compatibility overload.
     */
    public static void registerItem(
            Identifier itemId,
            Map<String, DelayConfig> properties
    ) {

        registerItem(
                itemId,
                Behavior.NORMAL,
                properties,
                Map.of()
        );
    }


    /*
     * ================================================================
     * CONDITIONAL PROPERTY CONFIG
     * ================================================================
     */
    public static DelayConfig get(
            Identifier itemId,
            String propertyName
    ) {

        ItemConfig itemConfig =
                CONFIGS.get(
                        itemId
                );


        if (itemConfig == null) {
            return null;
        }


        return itemConfig.properties().get(
                propertyName
        );
    }


    /*
     * ================================================================
     * RANGE PROPERTY CONFIG
     * ================================================================
     */
    public static RangeDelayConfig getRange(
            Identifier itemId,
            String propertyName
    ) {

        ItemConfig itemConfig =
                CONFIGS.get(
                        itemId
                );


        if (itemConfig == null) {
            return null;
        }


        return itemConfig.rangeProperties().get(
                propertyName
        );
    }


    /*
     * ================================================================
     * ITEM BEHAVIOR
     * ================================================================
     */
    public static Behavior getBehavior(
            Identifier itemId
    ) {

        ItemConfig itemConfig =
                CONFIGS.get(
                        itemId
                );


        if (itemConfig == null) {

            return Behavior.NORMAL;
        }


        return itemConfig.behavior();
    }


    public static boolean isEvolving(
            Identifier itemId
    ) {

        return getBehavior(itemId)
                == Behavior.EVOLVING;
    }
}