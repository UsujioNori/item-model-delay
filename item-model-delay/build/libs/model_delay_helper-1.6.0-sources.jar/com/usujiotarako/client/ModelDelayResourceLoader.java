package com.usujiotarako.client;

import net.fabricmc.fabric.api.resource.v1.ResourceLoader;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public final class ModelDelayResourceLoader {

    private static final String EXTENSION =
            ".mdprop";


    private static final String RANGE_PREFIX =
            "range.";


    private record LoadedItemConfig(
            ModelDelayConfig.Behavior behavior,
            Map<String, ModelDelayConfig.DelayConfig> properties,
            Map<String, ModelDelayConfig.RangeDelayConfig> rangeProperties
    ) {
    }


    private ModelDelayResourceLoader() {
    }


    /*
     * ================================================================
     * INITIALIZE
     * ================================================================
     */
    public static void initialize() {

        ResourceLoader.get(
                        PackType.CLIENT_RESOURCES
                )
                .registerReloadListener(

                        Identifier.fromNamespaceAndPath(
                                "model_delay_helper",
                                "mdprop_loader"
                        ),

                        new SimplePreparableReloadListener<
                                Map<Identifier, LoadedItemConfig>
                                >() {

                            @Override
                            protected Map<Identifier, LoadedItemConfig> prepare(
                                    ResourceManager manager,
                                    ProfilerFiller profiler
                            ) {

                                return load(
                                        manager
                                );
                            }


                            @Override
                            protected void apply(
                                    Map<Identifier, LoadedItemConfig> configs,
                                    ResourceManager manager,
                                    ProfilerFiller profiler
                            ) {

                                ModelDelayConfig.clear();

                                /*
                                 * Existing boolean / conditional state.
                                 */
                                ModelDelayState.clear();

                                /*
                                 * Numeric / range_dispatch state.
                                 */
                                ModelDelayRangeState.clear();


                                for (
                                        Map.Entry<
                                                Identifier,
                                                LoadedItemConfig
                                                > entry
                                        : configs.entrySet()
                                ) {

                                    LoadedItemConfig config =
                                            entry.getValue();


                                    ModelDelayConfig.registerItem(
                                            entry.getKey(),
                                            config.behavior(),
                                            config.properties(),
                                            config.rangeProperties()
                                    );
                                }
                            }
                        }
                );
    }


    /*
     * ================================================================
     * LOAD ALL .MDPROP FILES
     * ================================================================
     */
    private static Map<
            Identifier,
            LoadedItemConfig
            > load(
            ResourceManager manager
    ) {

        Map<
                Identifier,
                LoadedItemConfig
                > result =
                new HashMap<>();


        Map<Identifier, Resource> resources =
                manager.listResources(
                        "items",
                        id ->
                                id.getPath()
                                        .endsWith(
                                                EXTENSION
                                        )
                );


        for (
                Map.Entry<Identifier, Resource> entry
                : resources.entrySet()
        ) {

            Identifier configId =
                    entry.getKey();


            String path =
                    configId.getPath();


            String itemPath =
                    path.substring(
                            0,
                            path.length()
                                    - EXTENSION.length()
                    );


            /*
             * Convert:
             *
             * assets/minecraft/items/diamond_sword.mdprop
             *
             * into:
             *
             * minecraft:diamond_sword
             */
            if (!itemPath.startsWith("items/")) {
                continue;
            }


            String itemName =
                    itemPath.substring(
                            "items/".length()
                    );


            Identifier itemId =
                    Identifier.fromNamespaceAndPath(
                            configId.getNamespace(),
                            itemName
                    );


            LoadedItemConfig config =
                    loadFile(
                            entry.getValue()
                    );


            /*
             * Keep the item if it contains either:
             *
             *     conditional properties
             *
             * or:
             *
             *     range_dispatch properties
             */
            if (
                    !config.properties().isEmpty()
                            || !config.rangeProperties().isEmpty()
            ) {

                result.put(
                        itemId,
                        config
                );
            }
        }


        return result;
    }


    /*
     * ================================================================
     * LOAD ONE .MDPROP FILE
     * ================================================================
     */
    private static LoadedItemConfig loadFile(
            Resource resource
    ) {

        /*
         * Boolean conditional properties.
         */
        Map<
                String,
                ModelDelayConfig.DelayConfig
                > configs =
                new HashMap<>();


        /*
         * Numeric range_dispatch properties.
         */
        Map<
                String,
                ModelDelayConfig.RangeDelayConfig
                > rangeConfigs =
                new HashMap<>();


        Properties properties =
                new Properties();


        ModelDelayConfig.Behavior itemBehavior =
                ModelDelayConfig.Behavior.NORMAL;


        try (
                InputStream stream =
                        resource.open();

                InputStreamReader reader =
                        new InputStreamReader(
                                stream,
                                StandardCharsets.UTF_8
                        )
        ) {

            properties.load(
                    reader
            );


            /*
             * ========================================================
             * ITEM-LEVEL BEHAVIOR
             * ========================================================
             *
             *     behavior=normal
             *
             * or:
             *
             *     behavior=evolving
             */
            String itemBehaviorString =
                    properties.getProperty(
                                    "behavior",
                                    "normal"
                            )
                            .trim()
                            .toLowerCase();


            switch (itemBehaviorString) {

                case "normal" ->
                        itemBehavior =
                                ModelDelayConfig.Behavior.NORMAL;


                case "evolving" ->
                        itemBehavior =
                                ModelDelayConfig.Behavior.EVOLVING;


                default -> {

                    System.err.println(
                            "[Model Delay Helper] Unknown behavior '"
                                    + itemBehaviorString
                                    + "'. Using normal."
                    );


                    itemBehavior =
                            ModelDelayConfig.Behavior.NORMAL;
                }
            }


            /*
             * ========================================================
             * PROPERTY DELAYS
             * ========================================================
             */
            for (
                    String key
                    : properties.stringPropertyNames()
            ) {

                if (!key.endsWith(".delay")) {
                    continue;
                }


                String propertyName =
                        key.substring(
                                0,
                                key.length()
                                        - ".delay".length()
                        );


                /*
                 * ----------------------------------------------------
                 * DELAY
                 * ----------------------------------------------------
                 */
                int delay;


                try {

                    delay =
                            Integer.parseInt(
                                    properties
                                            .getProperty(key)
                                            .trim()
                            );

                } catch (NumberFormatException e) {

                    System.err.println(
                            "[Model Delay Helper] Invalid delay for "
                                    + propertyName
                    );


                    continue;
                }


                /*
                 * ====================================================
                 * RANGE_DISPATCH PROPERTY
                 * ====================================================
                 *
                 * Examples:
                 *
                 *     range.custom_model_data[0].delay=40
                 *
                 *     range.bundle/fullness.delay=40
                 *
                 *
                 * Default behavior:
                 *
                 *     threshold
                 *
                 *
                 * Optional explicit override:
                 *
                 *     range.bundle/fullness.behavior=value
                 */
                if (
                        propertyName.startsWith(
                                RANGE_PREFIX
                        )
                ) {

                    String rangeBehaviorString =
                            properties.getProperty(
                                            propertyName + ".behavior",

                                            /*
                                             * Threshold is now the default.
                                             */
                                            "threshold"
                                    )
                                    .trim()
                                    .toLowerCase();


                    ModelDelayConfig.RangeBehavior rangeBehavior;


                    switch (rangeBehaviorString) {

                        case "threshold" ->
                                rangeBehavior =
                                        ModelDelayConfig.RangeBehavior.THRESHOLD;


                        case "value" ->
                                rangeBehavior =
                                        ModelDelayConfig.RangeBehavior.VALUE;


                        default -> {

                            System.err.println(
                                    "[Model Delay Helper] Unknown range behavior '"
                                            + rangeBehaviorString
                                            + "' for "
                                            + propertyName
                                            + ". Using threshold."
                            );


                            /*
                             * Invalid range behavior also falls back to
                             * the normal/default threshold behavior.
                             */
                            rangeBehavior =
                                    ModelDelayConfig.RangeBehavior.THRESHOLD;
                        }
                    }


                    rangeConfigs.put(
                            propertyName,
                            new ModelDelayConfig.RangeDelayConfig(
                                    delay,
                                    rangeBehavior
                            )
                    );


                    /*
                     * Do not parse conditional mode/behavior fields for
                     * range_dispatch properties.
                     */
                    continue;
                }


                /*
                 * ====================================================
                 * CONDITIONAL PROPERTY
                 * ====================================================
                 */

                /*
                 * ----------------------------------------------------
                 * MODE
                 * ----------------------------------------------------
                 */
                String modeString =
                        properties.getProperty(
                                        propertyName + ".mode",
                                        "release"
                                )
                                .trim()
                                .toLowerCase();


                ModelDelayConfig.Mode mode;


                switch (modeString) {

                    case "hold" ->
                            mode =
                                    ModelDelayConfig.Mode.HOLD;


                    case "release" ->
                            mode =
                                    ModelDelayConfig.Mode.RELEASE;


                    case "both" ->
                            mode =
                                    ModelDelayConfig.Mode.BOTH;


                    default -> {

                        System.err.println(
                                "[Model Delay Helper] Unknown mode '"
                                        + modeString
                                        + "' for "
                                        + propertyName
                        );


                        mode =
                                ModelDelayConfig.Mode.RELEASE;
                    }
                }


                /*
                 * ----------------------------------------------------
                 * CONDITIONAL PROPERTY BEHAVIOR
                 * ----------------------------------------------------
                 */
                String propertyBehaviorString =
                        properties.getProperty(
                                        propertyName + ".behavior",
                                        "normal"
                                )
                                .trim()
                                .toLowerCase();


                ModelDelayConfig.PropertyBehavior propertyBehavior;


                switch (propertyBehaviorString) {

                    case "normal" ->
                            propertyBehavior =
                                    ModelDelayConfig.PropertyBehavior.NORMAL;


                    case "held" ->
                            propertyBehavior =
                                    ModelDelayConfig.PropertyBehavior.HELD;


                    default -> {

                        System.err.println(
                                "[Model Delay Helper] Unknown property behavior '"
                                        + propertyBehaviorString
                                        + "' for "
                                        + propertyName
                                        + ". Using normal."
                        );


                        propertyBehavior =
                                ModelDelayConfig.PropertyBehavior.NORMAL;
                    }
                }


                configs.put(
                        propertyName,
                        new ModelDelayConfig.DelayConfig(
                                delay,
                                mode,
                                propertyBehavior
                        )
                );
            }


        } catch (IOException e) {

            e.printStackTrace();
        }


        return new LoadedItemConfig(
                itemBehavior,
                configs,
                rangeConfigs
        );
    }
}