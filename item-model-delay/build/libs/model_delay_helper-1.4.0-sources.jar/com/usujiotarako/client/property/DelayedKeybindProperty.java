package com.usujiotarako.client.property;

public class DelayedKeybindProperty {
}
