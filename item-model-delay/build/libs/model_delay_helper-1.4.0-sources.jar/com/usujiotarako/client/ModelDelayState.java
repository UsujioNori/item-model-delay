package com.usujiotarako.client;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.jspecify.annotations.Nullable;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public final class ModelDelayState {

    /*
     * ================================================================
     * STATE KEY
     * ================================================================
     *
     * Normal properties:
     *
     *     item + property
     *
     * Player stack-sensitive properties:
     *
     *     item + property + player entity id + inventory slot
     *
     * Non-living world stack-sensitive properties:
     *
     *     item + property + render seed
     *
     * ItemModelResolver supplies a non-living entity's entity ID as the
     * model seed, so dropped items and item frames receive a stable
     * per-entity identity.
     */
    private record StateKey(
            Identifier item,
            String property,
            int ownerId,
            int slot,
            int worldSeed
    ) {
    }


    /*
     * The value currently displayed by the model.
     */
    private static final Map<StateKey, Boolean> CURRENT_VALUE =
            new HashMap<>();


    /*
     * Value a pending transition is trying to reach.
     */
    private static final Map<StateKey, Boolean> TARGET_VALUE =
            new HashMap<>();


    /*
     * Number of client ticks remaining before a delayed transition
     * completes.
     */
    private static final Map<StateKey, Integer> REMAINING =
            new HashMap<>();


    /*
     * Whether a delayed transition is currently active.
     */
    private static final Map<StateKey, Boolean> TRANSITIONING =
            new HashMap<>();


    /*
     * keybind_down + RELEASE only.
     *
     * Tracks how many client ticks the key has already remained TRUE.
     */
    private static final Map<StateKey, Integer> KEYBIND_RELEASE_ELAPSED =
            new HashMap<>();


    private ModelDelayState() {
    }


    /*
     * ================================================================
     * PROPERTY TYPES
     * ================================================================
     */

    /*
     * These properties depend on data belonging to an individual
     * ItemStack.
     *
     * Two instances of the same item can therefore legitimately report
     * different values at the same time.
     */
    private static boolean isStackSensitiveProperty(
            String property
    ) {

        return "damaged".equals(property)
                || "broken".equals(property);
    }


    /*
     * Only keybind_down currently uses elapsed RELEASE time.
     */
    private static boolean usesElapsedRelease(
            StateKey key
    ) {

        return "keybind_down".equals(
                key.property()
        );
    }


    /*
     * ================================================================
     * PLAYER SLOT RESOLUTION
     * ================================================================
     */
    private static int resolvePlayerSlot(
            ItemStack stack,
            Player player,
            ItemDisplayContext displayContext
    ) {

        Inventory inventory =
                player.getInventory();


        /*
         * ------------------------------------------------------------
         * HAND RENDERING
         * ------------------------------------------------------------
         */
        boolean handContext =
                displayContext
                        == ItemDisplayContext.FIRST_PERSON_RIGHT_HAND

                        || displayContext
                        == ItemDisplayContext.FIRST_PERSON_LEFT_HAND

                        || displayContext
                        == ItemDisplayContext.THIRD_PERSON_RIGHT_HAND

                        || displayContext
                        == ItemDisplayContext.THIRD_PERSON_LEFT_HAND;


        if (handContext) {

            ItemStack offhand =
                    inventory.getItem(
                            Inventory.SLOT_OFFHAND
                    );


            /*
             * Exact offhand stack.
             */
            if (offhand == stack) {

                return Inventory.SLOT_OFFHAND;
            }


            ItemStack selected =
                    inventory.getSelectedItem();


            /*
             * Exact selected/main-hand stack.
             */
            if (selected == stack) {

                return inventory.getSelectedSlot();
            }


            /*
             * Render-time stack copy matching the offhand.
             */
            if (
                    !offhand.isEmpty()
                            && ItemStack.isSameItemSameComponents(
                            stack,
                            offhand
                    )
            ) {

                return Inventory.SLOT_OFFHAND;
            }


            /*
             * Remaining hand evaluations are associated with the selected
             * hotbar location.
             */
            return inventory.getSelectedSlot();
        }


        /*
         * ------------------------------------------------------------
         * NORMAL INVENTORY
         * ------------------------------------------------------------
         *
         * Prefer exact object identity.
         */
        for (
                int slot = 0;
                slot < Inventory.INVENTORY_SIZE;
                slot++
        ) {

            if (inventory.getItem(slot) == stack) {

                return slot;
            }
        }


        /*
         * Exact offhand identity.
         */
        if (
                inventory.getItem(
                        Inventory.SLOT_OFFHAND
                ) == stack
        ) {

            return Inventory.SLOT_OFFHAND;
        }


        /*
         * ------------------------------------------------------------
         * RENDER-COPY FALLBACK
         * ------------------------------------------------------------
         */

        int selectedSlot =
                inventory.getSelectedSlot();


        ItemStack selected =
                inventory.getSelectedItem();


        if (
                !selected.isEmpty()
                        && ItemStack.isSameItemSameComponents(
                        stack,
                        selected
                )
        ) {

            return selectedSlot;
        }


        ItemStack offhand =
                inventory.getItem(
                        Inventory.SLOT_OFFHAND
                );


        if (
                !offhand.isEmpty()
                        && ItemStack.isSameItemSameComponents(
                        stack,
                        offhand
                )
        ) {

            return Inventory.SLOT_OFFHAND;
        }


        /*
         * Search remaining inventory for an equivalent render-time copy.
         */
        for (
                int slot = 0;
                slot < Inventory.INVENTORY_SIZE;
                slot++
        ) {

            ItemStack inventoryStack =
                    inventory.getItem(
                            slot
                    );


            if (
                    !inventoryStack.isEmpty()
                            && ItemStack.isSameItemSameComponents(
                            stack,
                            inventoryStack
                    )
            ) {

                return slot;
            }
        }


        return -1;
    }


    /*
     * ================================================================
     * STATE KEY CREATION
     * ================================================================
     */
    private static StateKey createKey(
            Identifier itemId,
            ItemStack stack,
            @Nullable LivingEntity owner,
            String property,
            int seed,
            ItemDisplayContext displayContext
    ) {

        /*
         * ------------------------------------------------------------
         * NORMAL PROPERTIES
         * ------------------------------------------------------------
         *
         * Preserve the existing shared behaviour.
         */
        if (!isStackSensitiveProperty(property)) {

            return new StateKey(
                    itemId,
                    property,
                    -1,
                    -1,
                    -1
            );
        }


        /*
         * ------------------------------------------------------------
         * PLAYER INVENTORY / HAND
         * ------------------------------------------------------------
         */
        if (owner instanceof Player player) {

            int slot =
                    resolvePlayerSlot(
                            stack,
                            player,
                            displayContext
                    );


            return new StateKey(
                    itemId,
                    property,
                    player.getId(),
                    slot,
                    -1
            );
        }


        /*
         * ------------------------------------------------------------
         * NON-LIVING WORLD ENTITY
         * ------------------------------------------------------------
         *
         * ItemModelResolver.updateForNonLiving() supplies entity.getId()
         * as the model seed.
         *
         * This gives dropped items and fixed/item-frame renders their own
         * stable state instead of making every stone sword on the ground
         * share one damaged/broken timer.
         */
        if (
                displayContext == ItemDisplayContext.GROUND
                        || displayContext == ItemDisplayContext.FIXED
        ) {

            return new StateKey(
                    itemId,
                    property,
                    -1,
                    -1,
                    seed
            );
        }


        /*
         * ------------------------------------------------------------
         * UNKNOWN / OWNERLESS CONTEXT
         * ------------------------------------------------------------
         *
         * GUI-style ownerless renders do not currently provide enough
         * information for a guaranteed unique physical-stack identity.
         *
         * Keep those on a shared fallback rather than guessing.
         */
        return new StateKey(
                itemId,
                property,
                -1,
                -1,
                -1
        );
    }


    /*
     * ================================================================
     * CLIENT TICK
     * ================================================================
     *
     * Called once per client tick.
     */
    public static void tick() {

        /*
         * ------------------------------------------------------------
         * KEYBIND RELEASE ELAPSED COUNTERS
         * ------------------------------------------------------------
         */
        for (Map.Entry<StateKey, Integer> entry
                : KEYBIND_RELEASE_ELAPSED.entrySet()) {

            int elapsed =
                    entry.getValue();


            if (elapsed < Integer.MAX_VALUE) {

                entry.setValue(
                        elapsed + 1
                );
            }
        }


        /*
         * ------------------------------------------------------------
         * PENDING TRANSITIONS
         * ------------------------------------------------------------
         */
        Iterator<Map.Entry<StateKey, Integer>> iterator =
                REMAINING.entrySet().iterator();


        while (iterator.hasNext()) {

            Map.Entry<StateKey, Integer> entry =
                    iterator.next();


            StateKey key =
                    entry.getKey();


            int remaining =
                    entry.getValue() - 1;


            if (remaining > 0) {

                entry.setValue(
                        remaining
                );

                continue;
            }


            /*
             * ========================================================
             * TRANSITION COMPLETE
             * ========================================================
             */
            boolean target =
                    TARGET_VALUE.getOrDefault(
                            key,
                            CURRENT_VALUE.getOrDefault(
                                    key,
                                    false
                            )
                    );


            CURRENT_VALUE.put(
                    key,
                    target
            );


            TARGET_VALUE.put(
                    key,
                    target
            );


            TRANSITIONING.put(
                    key,
                    false
            );


            iterator.remove();
        }
    }


    /*
     * ================================================================
     * GET
     * ================================================================
     */
    public static boolean get(
            ItemStack stack,
            @Nullable LivingEntity owner,
            String property,
            boolean vanillaValue,
            ModelDelayConfig.DelayConfig config,
            int seed,
            ItemDisplayContext displayContext
    ) {

        Identifier itemId =
                BuiltInRegistries.ITEM.getKey(
                        stack.getItem()
                );


        StateKey key =
                createKey(
                        itemId,
                        stack,
                        owner,
                        property,
                        seed,
                        displayContext
                );


        /*
         * Elapsed RELEASE belongs only to:
         *
         * keybind_down + RELEASE
         */
        if (
                config.mode() != ModelDelayConfig.Mode.RELEASE
                        || !usesElapsedRelease(key)
        ) {

            KEYBIND_RELEASE_ELAPSED.remove(
                    key
            );
        }


        /*
         * ============================================================
         * FIRST EVALUATION
         * ============================================================
         */
        if (!CURRENT_VALUE.containsKey(key)) {

            CURRENT_VALUE.put(
                    key,
                    vanillaValue
            );


            TARGET_VALUE.put(
                    key,
                    vanillaValue
            );


            TRANSITIONING.put(
                    key,
                    false
            );


            if (
                    config.mode() == ModelDelayConfig.Mode.RELEASE
                            && usesElapsedRelease(key)
                            && vanillaValue
            ) {

                KEYBIND_RELEASE_ELAPSED.put(
                        key,
                        0
                );
            }


            return vanillaValue;
        }


        boolean current =
                CURRENT_VALUE.get(
                        key
                );


        boolean transitioning =
                TRANSITIONING.getOrDefault(
                        key,
                        false
                );


        boolean target =
                TARGET_VALUE.getOrDefault(
                        key,
                        current
                );


        /*
         * ============================================================
         * HOLD
         * ============================================================
         *
         * FALSE -> TRUE delayed
         * TRUE  -> FALSE immediate
         */
        if (config.mode() == ModelDelayConfig.Mode.HOLD) {

            if (!vanillaValue) {

                CURRENT_VALUE.put(
                        key,
                        false
                );


                TARGET_VALUE.put(
                        key,
                        false
                );


                REMAINING.remove(
                        key
                );


                TRANSITIONING.put(
                        key,
                        false
                );


                return false;
            }


            if (current) {

                REMAINING.remove(
                        key
                );


                TARGET_VALUE.put(
                        key,
                        true
                );


                TRANSITIONING.put(
                        key,
                        false
                );


                return true;
            }


            if (!transitioning) {

                TARGET_VALUE.put(
                        key,
                        true
                );


                TRANSITIONING.put(
                        key,
                        true
                );


                if (config.delay() <= 0) {

                    CURRENT_VALUE.put(
                            key,
                            true
                    );


                    TRANSITIONING.put(
                            key,
                            false
                    );


                    return true;
                }


                REMAINING.put(
                        key,
                        config.delay()
                );
            }


            return CURRENT_VALUE.get(
                    key
            );
        }


        /*
         * ============================================================
         * RELEASE
         * ============================================================
         *
         * FALSE -> TRUE immediate
         *
         * keybind_down additionally subtracts time already spent held.
         */
        if (config.mode() == ModelDelayConfig.Mode.RELEASE) {

            boolean elapsedRelease =
                    usesElapsedRelease(
                            key
                    );


            /*
             * PROPERTY TRUE
             */
            if (vanillaValue) {

                CURRENT_VALUE.put(
                        key,
                        true
                );


                TARGET_VALUE.put(
                        key,
                        true
                );


                REMAINING.remove(
                        key
                );


                TRANSITIONING.put(
                        key,
                        false
                );


                if (elapsedRelease) {

                    KEYBIND_RELEASE_ELAPSED.putIfAbsent(
                            key,
                            0
                    );
                }


                return true;
            }


            /*
             * --------------------------------------------------------
             * KEYBIND ELAPSED RELEASE
             * --------------------------------------------------------
             */
            if (elapsedRelease) {

                int elapsed =
                        KEYBIND_RELEASE_ELAPSED.getOrDefault(
                                key,
                                0
                        );


                KEYBIND_RELEASE_ELAPSED.remove(
                        key
                );


                if (!current) {

                    REMAINING.remove(
                            key
                    );


                    TARGET_VALUE.put(
                            key,
                            false
                    );


                    TRANSITIONING.put(
                            key,
                            false
                    );


                    return false;
                }


                int remainingDelay =
                        Math.max(
                                0,
                                config.delay() - elapsed
                        );


                if (remainingDelay <= 0) {

                    CURRENT_VALUE.put(
                            key,
                            false
                    );


                    TARGET_VALUE.put(
                            key,
                            false
                    );


                    REMAINING.remove(
                            key
                    );


                    TRANSITIONING.put(
                            key,
                            false
                    );


                    return false;
                }


                if (!transitioning) {

                    TARGET_VALUE.put(
                            key,
                            false
                    );


                    TRANSITIONING.put(
                            key,
                            true
                    );


                    REMAINING.put(
                            key,
                            remainingDelay
                    );
                }


                return CURRENT_VALUE.get(
                        key
                );
            }


            /*
             * --------------------------------------------------------
             * NORMAL RELEASE
             * --------------------------------------------------------
             */

            if (!current) {

                REMAINING.remove(
                        key
                );


                TARGET_VALUE.put(
                        key,
                        false
                );


                TRANSITIONING.put(
                        key,
                        false
                );


                return false;
            }


            if (!transitioning) {

                TARGET_VALUE.put(
                        key,
                        false
                );


                TRANSITIONING.put(
                        key,
                        true
                );


                if (config.delay() <= 0) {

                    CURRENT_VALUE.put(
                            key,
                            false
                    );


                    TRANSITIONING.put(
                            key,
                            false
                    );


                    return false;
                }


                REMAINING.put(
                        key,
                        config.delay()
                );
            }


            return CURRENT_VALUE.get(
                    key
            );
        }


        /*
         * ============================================================
         * BOTH
         * ============================================================
         *
         * FALSE -> TRUE delayed
         * TRUE  -> FALSE delayed
         */
        if (config.mode() == ModelDelayConfig.Mode.BOTH) {

            if (transitioning) {

                /*
                 * Property returned to currently displayed state.
                 */
                if (vanillaValue == current) {

                    REMAINING.remove(
                            key
                    );


                    TARGET_VALUE.put(
                            key,
                            current
                    );


                    TRANSITIONING.put(
                            key,
                            false
                    );


                    return current;
                }


                /*
                 * Property reversed direction while transition was
                 * pending.
                 */
                if (vanillaValue != target) {

                    TARGET_VALUE.put(
                            key,
                            vanillaValue
                    );


                    if (config.delay() <= 0) {

                        CURRENT_VALUE.put(
                                key,
                                vanillaValue
                        );


                        TRANSITIONING.put(
                                key,
                                false
                        );


                        REMAINING.remove(
                                key
                        );


                        return vanillaValue;
                    }


                    REMAINING.put(
                            key,
                            config.delay()
                    );


                    return current;
                }


                return current;
            }


            /*
             * Already agrees with displayed state.
             */
            if (vanillaValue == current) {

                TARGET_VALUE.put(
                        key,
                        current
                );


                return current;
            }


            /*
             * Begin transition.
             */
            TARGET_VALUE.put(
                    key,
                    vanillaValue
            );


            if (config.delay() <= 0) {

                CURRENT_VALUE.put(
                        key,
                        vanillaValue
                );


                TARGET_VALUE.put(
                        key,
                        vanillaValue
                );


                TRANSITIONING.put(
                        key,
                        false
                );


                REMAINING.remove(
                        key
                );


                return vanillaValue;
            }


            TRANSITIONING.put(
                    key,
                    true
            );


            REMAINING.put(
                    key,
                    config.delay()
            );


            return current;
        }


        return vanillaValue;
    }


    /*
     * ================================================================
     * CLEAR
     * ================================================================
     */
    public static void clear() {

        CURRENT_VALUE.clear();
        TARGET_VALUE.clear();
        REMAINING.clear();
        TRANSITIONING.clear();
        KEYBIND_RELEASE_ELAPSED.clear();
    }
}