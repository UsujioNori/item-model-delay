package com.usujiotarako.client;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.item.properties.conditional.ItemModelPropertyTest;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.jspecify.annotations.Nullable;

/**
 * Wraps a vanilla boolean item-model property with the shared delayed-state
 * system.
 *
 * <p>The wrapped property normally remains the source of truth.
 *
 * <p>Some properties can produce temporary false values during rendering
 * even though their underlying gameplay state is still effectively true.
 * Those cases are normalized before being passed into ModelDelayState so
 * delayed HOLD/BOTH transitions are not repeatedly cancelled.
 */
public final class DelayedItemModelProperty
        implements ItemModelPropertyTest {

    private static final String USING_ITEM_CLASS =
            "net.minecraft.client.renderer.item.properties.conditional.IsUsingItem";

    private static final boolean PUNCHY_LOADED =
            FabricLoader.getInstance().isModLoaded("punchy");


    private final ItemModelPropertyTest original;
    private final String propertyName;


    public DelayedItemModelProperty(
            ItemModelPropertyTest original,
            String propertyName
    ) {
        this.original = original;
        this.propertyName = propertyName;
    }


    @Override
    public boolean get(
            ItemStack itemStack,
            @Nullable ClientLevel level,
            @Nullable LivingEntity owner,
            int seed,
            ItemDisplayContext displayContext
    ) {

        Identifier itemId =
                BuiltInRegistries.ITEM.getKey(
                        itemStack.getItem()
                );


        ModelDelayConfig.DelayConfig config =
                ModelDelayConfig.get(
                        itemId,
                        propertyName
                );


        /*
         * No delay configured:
         *
         * preserve the wrapped property's normal behaviour completely.
         */
        if (config == null) {

            return original.get(
                    itemStack,
                    level,
                    owner,
                    seed,
                    displayContext
            );
        }


        /*
         * Ask the actual runtime property for its normal result first.
         */
        boolean propertyValue =
                original.get(
                        itemStack,
                        level,
                        owner,
                        seed,
                        displayContext
                );


        /*
         * Value supplied to ModelDelayState.
         *
         * Normally this remains exactly the runtime property value.
         */
        boolean delayInput =
                propertyValue;


        /*
         * ============================================================
         * PUNCHY / USING_ITEM COMPATIBILITY
         * ============================================================
         *
         * Punchy may temporarily force IsUsingItem#get() false while its
         * animation system is active.
         *
         * If gameplay state still says this exact stack is being used,
         * ignore that temporary false for Model Delay's timer.
         */
        if (
                PUNCHY_LOADED
                        && "using_item".equals(propertyName)
                        && USING_ITEM_CLASS.equals(
                        original.getClass().getName()
                )
                        && owner != null
        ) {

            boolean gameplayUsingItem =
                    owner.isUsingItem()
                            && owner.getUseItem() == itemStack;


            if (gameplayUsingItem && !propertyValue) {

                delayInput = true;
            }
        }


        /*
         * ============================================================
         * SELECTED COMPATIBILITY
         * ============================================================
         *
         * Vanilla IsSelected uses exact object identity:
         *
         *     player.getInventory().getSelectedItem() == itemStack
         *
         * Minecraft can sometimes evaluate hand models using an equivalent
         * ItemStack copy instead of the exact inventory object.
         *
         * That produces temporary false values which can repeatedly cancel
         * HOLD/BOTH transitions.
         *
         * For hand rendering only, if the rendered stack is equivalent to
         * the player's selected stack, treat selected as TRUE for the delay
         * system.
         *
         * GUI/inventory rendering continues to trust vanilla exactly so
         * identical copies elsewhere in the inventory are not accidentally
         * considered selected.
         */
        if (
                "selected".equals(propertyName)
                        && !propertyValue
                        && owner instanceof LocalPlayer player
                        && isHandContext(displayContext)
        ) {

            ItemStack selectedStack =
                    player.getInventory().getSelectedItem();


            if (
                    !selectedStack.isEmpty()
                            && ItemStack.isSameItemSameComponents(
                            selectedStack,
                            itemStack
                    )
            ) {

                delayInput = true;
            }
        }


        /*
         * ModelDelayState remains responsible for the final property value.
         */
        return ModelDelayState.get(
                itemStack,
                owner,
                propertyName,
                delayInput,
                config,
                seed,
                displayContext
        );
    }


    /*
     * ================================================================
     * DISPLAY CONTEXT HELPERS
     * ================================================================
     */
    private static boolean isHandContext(
            ItemDisplayContext displayContext
    ) {

        return displayContext
                == ItemDisplayContext.FIRST_PERSON_RIGHT_HAND

                || displayContext
                == ItemDisplayContext.FIRST_PERSON_LEFT_HAND

                || displayContext
                == ItemDisplayContext.THIRD_PERSON_RIGHT_HAND

                || displayContext
                == ItemDisplayContext.THIRD_PERSON_LEFT_HAND;
    }
}