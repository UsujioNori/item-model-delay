package com.usujiotarako.client;

import net.minecraft.resources.Identifier;

import java.util.HashMap;
import java.util.Map;

public final class ModelDelayConfig {

    private static final Map<
            Identifier,
            Map<String, DelayConfig>
            > CONFIGS = new HashMap<>();

    private ModelDelayConfig() {
    }

    public enum Mode {
        HOLD,
        RELEASE,
        BOTH
    }

    public record DelayConfig(
            int delay,
            Mode mode
    ) {
    }

    public static void clear() {
        CONFIGS.clear();
    }

    public static void registerItem(
            Identifier itemId,
            Map<String, DelayConfig> properties
    ) {
        CONFIGS.put(
                itemId,
                new HashMap<>(properties)
        );
    }

    public static DelayConfig get(
            Identifier itemId,
            String propertyName
    ) {
        Map<String, DelayConfig> properties =
                CONFIGS.get(itemId);

        if (properties == null) {
            return null;
        }

        return properties.get(propertyName);
    }
}