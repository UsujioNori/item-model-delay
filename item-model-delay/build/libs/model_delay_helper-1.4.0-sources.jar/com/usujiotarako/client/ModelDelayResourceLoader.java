package com.usujiotarako.client;

import net.fabricmc.fabric.api.resource.v1.ResourceLoader;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public final class ModelDelayResourceLoader {

    private static final String EXTENSION = ".mdprop";

    private ModelDelayResourceLoader() {
    }

    public static void initialize() {

        ResourceLoader.get(PackType.CLIENT_RESOURCES)
                .registerReloadListener(
                        Identifier.fromNamespaceAndPath(
                                "model_delay_helper",
                                "mdprop_loader"
                        ),

                        new SimplePreparableReloadListener<
                                Map<Identifier, Map<String, ModelDelayConfig.DelayConfig>>
                                >() {

                            @Override
                            protected Map<Identifier, Map<String, ModelDelayConfig.DelayConfig>> prepare(
                                    ResourceManager manager,
                                    ProfilerFiller profiler
                            ) {
                                return load(manager);
                            }

                            @Override
                            protected void apply(
                                    Map<Identifier, Map<String, ModelDelayConfig.DelayConfig>> configs,
                                    ResourceManager manager,
                                    ProfilerFiller profiler
                            ) {
                                ModelDelayConfig.clear();
                                ModelDelayState.clear();

                                for (Map.Entry<Identifier, Map<String, ModelDelayConfig.DelayConfig>> entry : configs.entrySet()) {
                                    ModelDelayConfig.registerItem(
                                            entry.getKey(),
                                            entry.getValue()
                                    );
                                }
                            }
                        }
                );
    }

    private static Map<
            Identifier,
            Map<String, ModelDelayConfig.DelayConfig>
            > load(ResourceManager manager) {

        Map<
                Identifier,
                Map<String, ModelDelayConfig.DelayConfig>
                > result = new HashMap<>();

        Map<Identifier, Resource> resources =
                manager.listResources(
                        "items",
                        id -> id.getPath().endsWith(EXTENSION)
                );

        for (Map.Entry<Identifier, Resource> entry : resources.entrySet()) {

            Identifier configId = entry.getKey();

            String path = configId.getPath();

            String itemPath =
                    path.substring(
                            0,
                            path.length() - EXTENSION.length()
                    );

            /*
             * Convert:
             *
             * assets/minecraft/items/diamond_sword.mdprop
             *
             * into:
             *
             * minecraft:diamond_sword
             */

            if (!itemPath.startsWith("items/")) {
                continue;
            }

            String itemName =
                    itemPath.substring("items/".length());

            Identifier itemId =
                    Identifier.fromNamespaceAndPath(
                            configId.getNamespace(),
                            itemName
                    );

            Map<String, ModelDelayConfig.DelayConfig> config =
                    loadFile(entry.getValue());
            if (!config.isEmpty()) {
                result.put(itemId, config);
            }
        }

        return result;
    }

    private static Map<String, ModelDelayConfig.DelayConfig> loadFile(
            Resource resource
    ) {

        Map<String, ModelDelayConfig.DelayConfig> configs =
                new HashMap<>();

        Properties properties = new Properties();

        try (
                InputStream stream = resource.open();
                InputStreamReader reader =
                        new InputStreamReader(
                                stream,
                                StandardCharsets.UTF_8
                        )
        ) {

            properties.load(reader);

            for (String key : properties.stringPropertyNames()) {

                if (!key.endsWith(".delay")) {
                    continue;
                }

                String propertyName =
                        key.substring(
                                0,
                                key.length() - ".delay".length()
                        );

                int delay;

                try {
                    delay = Integer.parseInt(
                            properties.getProperty(key).trim()
                    );
                } catch (NumberFormatException e) {
                    System.err.println(
                            "[Model Delay Helper] Invalid delay for "
                                    + propertyName
                    );
                    continue;
                }

                String modeString =
                        properties.getProperty(
                                propertyName + ".mode",
                                "release"
                        ).trim().toLowerCase();

                ModelDelayConfig.Mode mode;

                switch (modeString) {

                    case "hold" -> mode = ModelDelayConfig.Mode.HOLD;

                    case "release" -> mode = ModelDelayConfig.Mode.RELEASE;

                    case "both" -> mode = ModelDelayConfig.Mode.BOTH;

                    default -> {
                        System.err.println(
                                "[Model Delay Helper] Unknown mode '"
                                        + modeString
                                        + "' for "
                                        + propertyName
                        );

                        mode = ModelDelayConfig.Mode.RELEASE;
                    }
                }

                configs.put(
                        propertyName,
                        new ModelDelayConfig.DelayConfig(
                                delay,
                                mode
                        )
                );
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return configs;
    }
}