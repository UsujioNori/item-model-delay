package com.usujiotarako.client;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.item.properties.conditional.ConditionalItemModelProperty;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.jspecify.annotations.Nullable;

public record DelayedKeybindDown(
        KeyMapping keybind,
        int delay
) implements ConditionalItemModelProperty {

    private static final Codec<KeyMapping> KEYBIND_CODEC =
            Codec.STRING.comapFlatMap(
                    id -> {
                        KeyMapping mapping = KeyMapping.get(id);

                        return mapping != null
                                ? DataResult.success(mapping)
                                : DataResult.error(() -> "Invalid keybind: " + id);
                    },
                    KeyMapping::getName
            );

    public static final MapCodec<DelayedKeybindDown> MAP_CODEC =
            RecordCodecBuilder.mapCodec(instance ->
                    instance.group(
                            KEYBIND_CODEC
                                    .fieldOf("keybind")
                                    .forGetter(DelayedKeybindDown::keybind),

                            Codec.intRange(0, Integer.MAX_VALUE)
                                    .optionalFieldOf("delay", 0)
                                    .forGetter(DelayedKeybindDown::delay)

                    ).apply(instance, DelayedKeybindDown::new)
            );

    @Override
    public boolean get(
            ItemStack itemStack,
            @Nullable ClientLevel level,
            @Nullable LivingEntity owner,
            int seed,
            ItemDisplayContext displayContext
    ) {
        return DelayedKeybindManager.isDown(keybind, delay);
    }

    @Override
    public MapCodec<DelayedKeybindDown> type() {
        return MAP_CODEC;
    }
}