package com.usujiotarako.client;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.KeyMapping;

import java.util.IdentityHashMap;
import java.util.Map;

public final class DelayedKeybindManager {

    private static final Map<KeyMapping, Integer> RELEASE_TICKS =
            new IdentityHashMap<>();

    private static final Map<KeyMapping, Boolean> WAS_DOWN =
            new IdentityHashMap<>();

    private DelayedKeybindManager() {
    }

    public static void initialize() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            for (Map.Entry<KeyMapping, Integer> entry : RELEASE_TICKS.entrySet()) {
                KeyMapping keybind = entry.getKey();

                if (keybind.isDown()) {
                    // Key is held, so there is no release countdown.
                    entry.setValue(0);
                    WAS_DOWN.put(keybind, true);
                } else if (WAS_DOWN.getOrDefault(keybind, false)) {
                    // Key was just released.
                    WAS_DOWN.put(keybind, false);
                    entry.setValue(1);
                } else if (entry.getValue() > 0) {
                    // Continue counting after release.
                    entry.setValue(entry.getValue() + 1);
                }
            }
        });
    }

    public static boolean isDown(KeyMapping keybind, int delay) {
        RELEASE_TICKS.putIfAbsent(keybind, 0);
        WAS_DOWN.putIfAbsent(keybind, keybind.isDown());

        // Currently holding the key = immediately TRUE.
        if (keybind.isDown()) {
            return true;
        }

        // Not holding it anymore, but keep it TRUE during the delay.
        return RELEASE_TICKS.get(keybind) <= delay;
    }
}