package com.usujiotarako;

import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Shared constants and utilities for Model Delay Helper.
 */
public final class ModelDelayHelper {

	public static final String MOD_ID = "model_delay_helper";

	public static final Logger LOGGER =
			LoggerFactory.getLogger(MOD_ID);


	private ModelDelayHelper() {
	}


	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(
				MOD_ID,
				path
		);
	}
}