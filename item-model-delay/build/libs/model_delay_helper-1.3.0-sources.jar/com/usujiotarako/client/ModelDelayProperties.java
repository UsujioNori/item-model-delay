package com.usujiotarako.client;

import net.minecraft.client.renderer.item.properties.conditional.Broken;
import net.minecraft.client.renderer.item.properties.conditional.Damaged;
import net.minecraft.client.renderer.item.properties.conditional.FishingRodCast;
import net.minecraft.client.renderer.item.properties.conditional.IsCarried;
import net.minecraft.client.renderer.item.properties.conditional.IsKeybindDown;
import net.minecraft.client.renderer.item.properties.conditional.IsSelected;
import net.minecraft.client.renderer.item.properties.conditional.IsUsingItem;
import net.minecraft.resources.Identifier;

public final class ModelDelayProperties {

    private ModelDelayProperties() {
    }

    public static String getName(Object property) {

        if (property instanceof IsKeybindDown) {
            return "keybind_down";
        }

        if (property instanceof IsUsingItem) {
            return "using_item";
        }

        if (property instanceof IsSelected) {
            return "selected";
        }

        if (property instanceof IsCarried) {
            return "carried";
        }

        if (property instanceof Broken) {
            return "broken";
        }

        if (property instanceof Damaged) {
            return "damaged";
        }

        if (property instanceof FishingRodCast) {
            return "fishing_rod/cast";
        }

        return null;
    }
}