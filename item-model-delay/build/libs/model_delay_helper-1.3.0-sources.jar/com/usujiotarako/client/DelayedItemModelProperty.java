package com.usujiotarako.client;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.item.properties.conditional.ItemModelPropertyTest;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.jspecify.annotations.Nullable;

/**
 * Wraps a vanilla boolean item-model property with the shared delayed-state
 * system.
 *
 * <p>The wrapped property normally remains the source of truth. A small
 * compatibility exception is made for Punchy's handling of using_item:
 * Punchy may temporarily force IsUsingItem#get() to false for animation
 * purposes even while the exact stack is still genuinely being used.
 *
 * <p>Those temporary false values are ignored as delay-state transitions so
 * that HOLD and BOTH are not repeatedly cancelled. ModelDelayState's delayed
 * value remains the final model-property result, allowing Punchy's separate
 * arm/item-grip animations to continue normally.
 */
public final class DelayedItemModelProperty
        implements ItemModelPropertyTest {

    private static final String USING_ITEM_CLASS =
            "net.minecraft.client.renderer.item.properties.conditional.IsUsingItem";

    private static final boolean PUNCHY_LOADED =
            FabricLoader.getInstance().isModLoaded("punchy");


    private final ItemModelPropertyTest original;
    private final String propertyName;


    public DelayedItemModelProperty(
            ItemModelPropertyTest original,
            String propertyName
    ) {
        this.original = original;
        this.propertyName = propertyName;
    }


    @Override
    public boolean get(
            ItemStack itemStack,
            @Nullable ClientLevel level,
            @Nullable LivingEntity owner,
            int seed,
            ItemDisplayContext displayContext
    ) {

        Identifier itemId =
                BuiltInRegistries.ITEM.getKey(
                        itemStack.getItem()
                );


        ModelDelayConfig.DelayConfig config =
                ModelDelayConfig.get(
                        itemId,
                        propertyName
                );


        /*
         * No delay configured:
         * preserve the wrapped property's normal behavior completely.
         */
        if (config == null) {

            return original.get(
                    itemStack,
                    level,
                    owner,
                    seed,
                    displayContext
            );
        }


        boolean propertyValue =
                original.get(
                        itemStack,
                        level,
                        owner,
                        seed,
                        displayContext
                );


        boolean delayInput =
                propertyValue;


        /*
         * Punchy compatibility for minecraft:using_item.
         *
         * Punchy may temporarily force IsUsingItem#get() false while its
         * animation system is active. If vanilla gameplay state still says
         * this exact ItemStack is being used, do not allow that temporary
         * render-state false to reset the Model Delay transition.
         */
        if (
                PUNCHY_LOADED
                        && "using_item".equals(propertyName)
                        && USING_ITEM_CLASS.equals(
                        original.getClass().getName()
                )
                        && owner != null
        ) {

            boolean gameplayUsingItem =
                    owner.isUsingItem()
                            && owner.getUseItem() == itemStack;


            if (gameplayUsingItem && !propertyValue) {
                delayInput = true;
            }
        }


        return ModelDelayState.get(
                itemStack,
                owner,
                propertyName,
                delayInput,
                config,
                displayContext
        );
    }
}