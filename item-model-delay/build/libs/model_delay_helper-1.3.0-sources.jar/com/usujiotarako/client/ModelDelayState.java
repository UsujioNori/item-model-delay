package com.usujiotarako.client;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.jspecify.annotations.Nullable;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public final class ModelDelayState {

    /*
     * One delayed state per:
     *
     * item + property
     *
     * owner and displayContext are deliberately NOT part of this key.
     */
    private record StateKey(
            Identifier item,
            String property
    ) {
    }


    /*
     * The value currently being displayed by the model.
     */
    private static final Map<StateKey, Boolean> CURRENT_VALUE =
            new HashMap<>();


    /*
     * The vanilla/property value we are waiting to switch to.
     */
    private static final Map<StateKey, Boolean> TARGET_VALUE =
            new HashMap<>();


    /*
     * Number of client ticks remaining before the transition completes.
     */
    private static final Map<StateKey, Integer> REMAINING =
            new HashMap<>();


    /*
     * Whether this state currently has a delayed transition.
     */
    private static final Map<StateKey, Boolean> TRANSITIONING =
            new HashMap<>();


    private ModelDelayState() {
    }


    /*
     * ================================================================
     * CLIENT TICK
     * ================================================================
     *
     * Called once per client tick.
     */
    public static void tick() {

        Iterator<Map.Entry<StateKey, Integer>> iterator =
                REMAINING.entrySet().iterator();

        while (iterator.hasNext()) {

            Map.Entry<StateKey, Integer> entry =
                    iterator.next();

            StateKey key =
                    entry.getKey();

            int remaining =
                    entry.getValue() - 1;


            /*
             * Still waiting.
             */
            if (remaining > 0) {

                entry.setValue(remaining);

                continue;
            }


            /*
             * ========================================================
             * TRANSITION COMPLETE
             * ========================================================
             *
             * Commit the target value once the configured number of
             * client ticks has elapsed.
             */
            boolean target =
                    TARGET_VALUE.getOrDefault(
                            key,
                            CURRENT_VALUE.getOrDefault(
                                    key,
                                    false
                            )
                    );


            CURRENT_VALUE.put(
                    key,
                    target
            );


            TARGET_VALUE.put(
                    key,
                    target
            );


            TRANSITIONING.put(
                    key,
                    false
            );


            iterator.remove();
        }
    }


    /*
     * ================================================================
     * GET
     * ================================================================
     *
     * Called whenever Minecraft evaluates one of the wrapped conditional
     * item-model properties.
     *
     * owner and displayContext are retained in the method signature for
     * compatibility with the wrapper and possible future state handling.
     */
    public static boolean get(
            ItemStack stack,
            @Nullable LivingEntity owner,
            String property,
            boolean vanillaValue,
            ModelDelayConfig.DelayConfig config,
            ItemDisplayContext displayContext
    ) {

        Identifier itemId =
                BuiltInRegistries.ITEM.getKey(
                        stack.getItem()
                );


        StateKey key =
                new StateKey(
                        itemId,
                        property
                );


        /*
         * ============================================================
         * FIRST EVALUATION
         * ============================================================
         *
         * Begin with whatever Minecraft currently reports.
         */
        if (!CURRENT_VALUE.containsKey(key)) {

            CURRENT_VALUE.put(
                    key,
                    vanillaValue
            );


            TARGET_VALUE.put(
                    key,
                    vanillaValue
            );


            TRANSITIONING.put(
                    key,
                    false
            );


            return vanillaValue;
        }


        boolean current =
                CURRENT_VALUE.get(key);


        boolean transitioning =
                TRANSITIONING.getOrDefault(
                        key,
                        false
                );


        boolean target =
                TARGET_VALUE.getOrDefault(
                        key,
                        current
                );


        /*
         * ============================================================
         * HOLD
         * ============================================================
         *
         * FALSE -> TRUE delayed
         * TRUE  -> FALSE immediate
         */
        if (config.mode() == ModelDelayConfig.Mode.HOLD) {

            /*
             * Releasing is immediate.
             *
             * Also cancels a pending activation.
             */
            if (!vanillaValue) {

                CURRENT_VALUE.put(
                        key,
                        false
                );


                TARGET_VALUE.put(
                        key,
                        false
                );


                REMAINING.remove(key);


                TRANSITIONING.put(
                        key,
                        false
                );


                return false;
            }


            /*
             * Already displaying TRUE.
             */
            if (current) {

                REMAINING.remove(key);


                TARGET_VALUE.put(
                        key,
                        true
                );


                TRANSITIONING.put(
                        key,
                        false
                );


                return true;
            }


            /*
             * Vanilla/property state is TRUE while displayed value is FALSE.
             *
             * Start delayed activation.
             */
            if (!transitioning) {

                TARGET_VALUE.put(
                        key,
                        true
                );


                TRANSITIONING.put(
                        key,
                        true
                );


                if (config.delay() <= 0) {

                    CURRENT_VALUE.put(
                            key,
                            true
                    );


                    TRANSITIONING.put(
                            key,
                            false
                    );


                    return true;
                }


                REMAINING.put(
                        key,
                        config.delay()
                );
            }


            return CURRENT_VALUE.get(key);
        }


        /*
         * ============================================================
         * RELEASE
         * ============================================================
         *
         * TRUE  -> FALSE delayed
         * FALSE -> TRUE immediate
         */
        if (config.mode() == ModelDelayConfig.Mode.RELEASE) {

            /*
             * Starting use is immediate.
             */
            if (vanillaValue) {

                CURRENT_VALUE.put(
                        key,
                        true
                );


                TARGET_VALUE.put(
                        key,
                        true
                );


                REMAINING.remove(key);


                TRANSITIONING.put(
                        key,
                        false
                );


                return true;
            }


            /*
             * Already displaying FALSE.
             */
            if (!current) {

                REMAINING.remove(key);


                TARGET_VALUE.put(
                        key,
                        false
                );


                TRANSITIONING.put(
                        key,
                        false
                );


                return false;
            }


            /*
             * TRUE -> FALSE needs to be delayed.
             */
            if (!transitioning) {

                TARGET_VALUE.put(
                        key,
                        false
                );


                TRANSITIONING.put(
                        key,
                        true
                );


                if (config.delay() <= 0) {

                    CURRENT_VALUE.put(
                            key,
                            false
                    );


                    TRANSITIONING.put(
                            key,
                            false
                    );


                    return false;
                }


                REMAINING.put(
                        key,
                        config.delay()
                );
            }


            /*
             * Keep returning TRUE until tick() commits FALSE.
             */
            return CURRENT_VALUE.get(key);
        }


        /*
         * ============================================================
         * BOTH
         * ============================================================
         *
         * FALSE -> TRUE delayed
         * TRUE  -> FALSE delayed
         */
        if (config.mode() == ModelDelayConfig.Mode.BOTH) {

            /*
             * --------------------------------------------------------
             * ACTIVE TRANSITION
             * --------------------------------------------------------
             */
            if (transitioning) {

                /*
                 * Property returned to the currently displayed state.
                 *
                 * Cancel the pending transition.
                 */
                if (vanillaValue == current) {

                    REMAINING.remove(key);


                    TARGET_VALUE.put(
                            key,
                            current
                    );


                    TRANSITIONING.put(
                            key,
                            false
                    );


                    return current;
                }


                /*
                 * Property changed direction while transition was still
                 * pending.
                 */
                if (vanillaValue != target) {

                    TARGET_VALUE.put(
                            key,
                            vanillaValue
                    );


                    if (config.delay() <= 0) {

                        CURRENT_VALUE.put(
                                key,
                                vanillaValue
                        );


                        TRANSITIONING.put(
                                key,
                                false
                        );


                        REMAINING.remove(key);


                        return vanillaValue;
                    }


                    REMAINING.put(
                            key,
                            config.delay()
                    );


                    return current;
                }


                /*
                 * Target has not changed.
                 */
                return current;
            }


            /*
             * Property already agrees with the displayed value.
             */
            if (vanillaValue == current) {

                TARGET_VALUE.put(
                        key,
                        current
                );


                return current;
            }


            /*
             * Begin a delayed transition.
             */
            TARGET_VALUE.put(
                    key,
                    vanillaValue
            );


            if (config.delay() <= 0) {

                CURRENT_VALUE.put(
                        key,
                        vanillaValue
                );


                TARGET_VALUE.put(
                        key,
                        vanillaValue
                );


                TRANSITIONING.put(
                        key,
                        false
                );


                REMAINING.remove(key);


                return vanillaValue;
            }


            TRANSITIONING.put(
                    key,
                    true
            );


            REMAINING.put(
                    key,
                    config.delay()
            );


            return current;
        }


        /*
         * Unknown mode.
         *
         * Fall back to vanilla/property value.
         */
        return vanillaValue;
    }


    /*
     * ================================================================
     * CLEAR
     * ================================================================
     */
    public static void clear() {

        CURRENT_VALUE.clear();
        TARGET_VALUE.clear();
        REMAINING.clear();
        TRANSITIONING.clear();
    }
}